// /controllers/userController.js - Controlador de Usuarios

import { User, Role } from '../models/index.js';
import { Op } from 'sequelize';
import bcrypt from 'bcrypt';

// GET /users - Obtener lista de usuarios
export const getUsers = async (req, res) => {
  try {
    console.log('🔍 GET /users - Usuario solicitante:', req.user);

    // Verificar que el usuario es admin
    if (req.user && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Permisos insuficientes',
        code: 'INSUFFICIENT_PERMISSIONS'
      });
    }

    // Obtener parámetros de query
    const {
      page = 1,
      limit = 20,
      role,
      search,
      is_active
    } = req.query;

    // Construir condiciones WHERE
    const whereConditions = {
      deleted_at: null // ✅ CRÍTICO: Solo usuarios NO eliminados
    };

    // Filtro por rol
    if (role) {
      whereConditions.role_id = role;
    }

    // Filtro por estado activo
    if (is_active !== undefined) {
      whereConditions.is_active = is_active === 'true';
    }

    // Filtro de búsqueda
    if (search) {
      whereConditions[Op.or] = [
        { first_name: { [Op.like]: `%${search}%` } },
        { last_name: { [Op.like]: `%${search}%` } },
        { email: { [Op.like]: `%${search}%` } },
        { username: { [Op.like]: `%${search}%` } }
      ];
    }

    // Calcular offset para paginación
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const offset = (pageNum - 1) * limitNum;

    // Consultar base de datos con Sequelize
    const { count, rows } = await User.findAndCountAll({
      where: whereConditions,
      include: [
        {
          model: Role,
          as: 'role',
          attributes: ['id', 'name']
        }
      ],
      attributes: {
        exclude: ['password_hash', 'password_reset_token', 'password_reset_expires']
      },
      limit: limitNum,
      offset: offset,
      order: [['created_at', 'DESC']],
      distinct: true
    });

    // Respuesta con paginación
    res.json({
      success: true,
      message: 'Usuarios obtenidos exitosamente',
      data: {
        items: rows,
        pagination: {
          page: pageNum,
          limit: limitNum,
          total: count,
          pages: Math.ceil(count / limitNum)
        }
      }
    });

  } catch (error) {
    console.error('❌ Error obteniendo usuarios:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};

// GET /users/:id - Obtener usuario por ID
export const getUserById = async (req, res) => {
  try {
    const { id } = req.params;

    // Buscar usuario en la base de datos
    const user = await User.findOne({
      where: {
        id,
        deleted_at: null // Solo usuarios NO eliminados
      },
      include: [
        {
          model: Role,
          as: 'role',
          attributes: ['id', 'name']
        }
      ],
      attributes: {
        exclude: ['password_hash', 'password_reset_token', 'password_reset_expires']
      }
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado',
        code: 'USER_NOT_FOUND'
      });
    }

    res.json({
      success: true,
      message: 'Usuario obtenido exitosamente',
      data: user
    });

  } catch (error) {
    console.error('❌ Error obteniendo usuario:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};

// POST /users - Crear nuevo usuario
export const createUser = async (req, res) => {
  try {
    console.log('🆕 POST /users - Creando usuario:', req.body);

    const {
      username,
      email,
      password,
      first_name,
      last_name,
      role_id
    } = req.body;

    // Validaciones básicas
    if (!username || !email || !password || !first_name || !last_name || !role_id) {
      return res.status(400).json({
        success: false,
        message: 'Todos los campos son requeridos',
        errors: [
          { field: 'username', message: 'Username es requerido' },
          { field: 'email', message: 'Email es requerido' },
          { field: 'password', message: 'Password es requerido' },
          { field: 'first_name', message: 'Nombre es requerido' },
          { field: 'last_name', message: 'Apellido es requerido' },
          { field: 'role_id', message: 'Rol es requerido' }
        ].filter(error => !req.body[error.field.replace('_', '')] && !req.body[error.field])
      });
    }

    // Verificar que no exista usuario con el mismo email/username
    const existingUser = await User.findOne({
      where: {
        [Op.or]: [
          { email },
          { username }
        ],
        deleted_at: null
      }
    });

    if (existingUser) {
      const field = existingUser.email === email ? 'email' : 'username';
      return res.status(400).json({
        success: false,
        message: `El ${field} ya está registrado`,
        code: 'USER_ALREADY_EXISTS'
      });
    }

    // Validar rol
    const role = await Role.findByPk(role_id);
    if (!role) {
      return res.status(400).json({
        success: false,
        message: 'Rol inválido',
        code: 'INVALID_ROLE'
      });
    }

    // Hashear contraseña
    const password_hash = await bcrypt.hash(password, 12);

    // Crear nuevo usuario en la base de datos
    const newUser = await User.create({
      username,
      email,
      password_hash,
      first_name,
      last_name,
      role_id,
      is_active: true
    });

    // Obtener usuario completo con rol
    const userWithRole = await User.findOne({
      where: { id: newUser.id },
      include: [
        {
          model: Role,
          as: 'role',
          attributes: ['id', 'name']
        }
      ],
      attributes: {
        exclude: ['password_hash', 'password_reset_token', 'password_reset_expires']
      }
    });

    console.log('✅ Usuario creado exitosamente:', newUser.id);

    res.status(201).json({
      success: true,
      message: 'Usuario creado exitosamente',
      data: userWithRole
    });

  } catch (error) {
    console.error('❌ Error creando usuario:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};

// PUT /users/:id - Actualizar usuario
export const updateUser = async (req, res) => {
  try {
    const { id } = req.params;

    console.log('📝 PUT /users/:id - Actualizando usuario:', id, req.body);

    // Buscar usuario
    const user = await User.findOne({
      where: {
        id,
        deleted_at: null
      }
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado',
        code: 'USER_NOT_FOUND'
      });
    }

    // Campos permitidos para actualizar
    const allowedFields = ['first_name', 'last_name', 'email', 'username', 'is_active', 'role_id'];
    const updates = {};

    // Filtrar solo campos permitidos
    Object.keys(req.body).forEach(key => {
      if (allowedFields.includes(key) && req.body[key] !== undefined) {
        updates[key] = req.body[key];
      }
    });

    // Si se actualiza email o username, verificar que no exista
    if (updates.email || updates.username) {
      const existingUser = await User.findOne({
        where: {
          [Op.or]: [
            updates.email ? { email: updates.email } : null,
            updates.username ? { username: updates.username } : null
          ].filter(Boolean),
          id: { [Op.ne]: id },
          deleted_at: null
        }
      });

      if (existingUser) {
        const field = existingUser.email === updates.email ? 'email' : 'username';
        return res.status(400).json({
          success: false,
          message: `El ${field} ya está en uso`,
          code: 'DUPLICATE_FIELD'
        });
      }
    }

    // Actualizar usuario
    await user.update(updates);

    // Obtener usuario actualizado con rol
    const updatedUser = await User.findOne({
      where: { id },
      include: [
        {
          model: Role,
          as: 'role',
          attributes: ['id', 'name']
        }
      ],
      attributes: {
        exclude: ['password_hash', 'password_reset_token', 'password_reset_expires']
      }
    });

    console.log('✅ Usuario actualizado exitosamente:', id);

    res.json({
      success: true,
      message: 'Usuario actualizado exitosamente',
      data: updatedUser
    });

  } catch (error) {
    console.error('❌ Error actualizando usuario:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};

// DELETE /users/:id - Eliminar usuario (soft delete)
export const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;

    console.log('🗑️ DELETE /users/:id - Eliminando usuario:', id);

    // Buscar usuario
    const user = await User.findOne({
      where: {
        id,
        deleted_at: null // Solo usuarios NO eliminados
      }
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado',
        code: 'USER_NOT_FOUND'
      });
    }

    // No permitir eliminar admin principal
    if (user.role_id === 1 && user.id === 1) {
      return res.status(400).json({
        success: false,
        message: 'No se puede eliminar el usuario administrador principal',
        code: 'CANNOT_DELETE_MAIN_ADMIN'
      });
    }

    // ✅ SOFT DELETE - Marcar deleted_at con timestamp
    await user.update({
      deleted_at: new Date(),
      is_active: false
    });

    console.log('✅ Usuario eliminado exitosamente (soft delete):', id);

    res.json({
      success: true,
      message: 'Usuario eliminado exitosamente'
    });

  } catch (error) {
    console.error('❌ Error eliminando usuario:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};

// POST /users/:id/reset-password - Resetear contraseña
export const resetPassword = async (req, res) => {
  try {
    const { id } = req.params;
    const { new_password, newPassword } = req.body;
    const password = new_password || newPassword; // Soportar ambos formatos

    console.log('🔑 POST /users/:id/reset-password - Reseteando contraseña:', id);

    if (!password) {
      return res.status(400).json({
        success: false,
        message: 'Nueva contraseña es requerida',
        errors: [{ field: 'new_password', message: 'Nueva contraseña es requerida' }]
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'La contraseña debe tener al menos 6 caracteres',
        errors: [{ field: 'new_password', message: 'Mínimo 6 caracteres' }]
      });
    }

    // Buscar usuario
    const user = await User.findOne({
      where: {
        id,
        deleted_at: null
      }
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado',
        code: 'USER_NOT_FOUND'
      });
    }

    // Hashear nueva contraseña
    const password_hash = await bcrypt.hash(password, 12);

    // Actualizar contraseña
    await user.update({
      password_hash,
      password_changed_at: new Date()
    });

    console.log('✅ Contraseña reseteada exitosamente para usuario:', id);

    res.json({
      success: true,
      message: 'Contraseña actualizada exitosamente'
    });

  } catch (error) {
    console.error('❌ Error reseteando contraseña:', error);
    res.status(500).json({
      success: false,
      message: 'Error interno del servidor'
    });
  }
};
